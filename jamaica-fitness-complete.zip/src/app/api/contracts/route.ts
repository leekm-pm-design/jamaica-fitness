// src/app/api/contracts/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(req: NextRequest) {
  try {
    const { name, phone, membershipType, signatureData, agreedTerms } = await req.json();

    // 입력값 검증
    if (!name || !phone || !membershipType || !signatureData) {
      return NextResponse.json(
        { error: '필수 항목을 입력해주세요' },
        { status: 400 }
      );
    }

    if (!agreedTerms) {
      return NextResponse.json(
        { error: '약관에 동의해주세요' },
        { status: 400 }
      );
    }

    // 전화번호 형식 정규화 (선택사항)
    const normalizedPhone = phone.replace(/[^0-9]/g, '');

    // 동일 전화번호 고객 존재 여부 확인
    let customer = await prisma.customer.findFirst({
      where: { phone: normalizedPhone }
    });

    if (!customer) {
      // 새 고객 생성
      customer = await prisma.customer.create({
        data: {
          name,
          phone: normalizedPhone,
          membershipType
        },
      });
    } else {
      // 기존 고객의 정보 업데이트 (이름과 회원권 타입)
      customer = await prisma.customer.update({
        where: { id: customer.id },
        data: {
          name,
          membershipType
        }
      });
    }

    // 새 계약 생성
    const contract = await prisma.contract.create({
      data: {
        customerId: customer.id,
        signatureData,
        agreedTerms,
      },
    });

    return NextResponse.json(
      {
        success: true,
        contractId: contract.id,
        customerId: customer.id
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('계약 생성 오류:', error);
    return NextResponse.json(
      { error: '서버 오류가 발생했습니다' },
      { status: 500 }
    );
  }
}