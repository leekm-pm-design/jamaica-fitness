// src/app/page.tsx
import ContractForm from '@/components/ContractForm';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <ContractForm />
    </div>
  );
}