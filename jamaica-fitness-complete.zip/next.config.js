/** @type {import('next').NextConfig} */
const nextConfig = {
  // appDir은 Next.js 14에서 기본으로 활성화되므로 제거
}

module.exports = nextConfig